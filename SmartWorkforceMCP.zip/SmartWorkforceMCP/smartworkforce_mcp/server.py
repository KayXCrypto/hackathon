import json
import logging
import os
import sqlite3
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from mcp.server import MCPServer

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(BASE_DIR / "mcp.log", encoding="utf-8")
    ],
)
log = logging.getLogger("smart-workforce-mcp")

MCP = MCPServer("Smart Workforce MCP")

API_BASE_URL = os.getenv("WORKFORCE_API_BASE_URL", "").rstrip("/")
API_TOKEN = os.getenv("WORKFORCE_API_TOKEN", "")
API_TIMEOUT = int(os.getenv("API_TIMEOUT_SECONDS", "30"))
DB_PATH = Path(os.getenv("POSTER_DB_PATH", str(BASE_DIR / "posters.db"))).resolve()

# API paths are configurable. They are fixed server-side; callers cannot supply arbitrary URLs.
ENDPOINTS = {
    "production_plan": os.getenv("API_PRODUCTION_PLAN_PATH", "/api/production/plan"),
    "manpower_standard": os.getenv("API_MANPOWER_STANDARD_PATH", "/api/workforce/manpower-standard"),
    "available_workforce": os.getenv("API_AVAILABLE_WORKFORCE_PATH", "/api/workforce/available"),
    "workforce_forecast": os.getenv("API_WORKFORCE_FORECAST_PATH", "/api/workforce/forecast"),
    "attendance_rate": os.getenv("API_ATTENDANCE_RATE_PATH", "/api/attendance/rate"),
    "absenteeism_trend": os.getenv("API_ABSENTEEISM_TREND_PATH", "/api/attendance/absenteeism-trend"),
    "turnover_rate": os.getenv("API_TURNOVER_RATE_PATH", "/api/turnover/rate"),
    "risk_analysis": os.getenv("API_RISK_ANALYSIS_PATH", "/api/workforce/risk-analysis"),
    "risk_alerts": os.getenv("API_RISK_ALERTS_PATH", "/api/workforce/risk-alerts"),
    "recruitment_quantity": os.getenv("API_RECRUITMENT_QUANTITY_PATH", "/api/recruitment/quantity"),
    "recruitment_cost": os.getenv("API_RECRUITMENT_COST_PATH", "/api/recruitment/cost"),
    "hiring_scenario": os.getenv("API_HIRING_SCENARIO_PATH", "/api/recruitment/scenario"),
    "scenario_comparison": os.getenv("API_SCENARIO_COMPARISON_PATH", "/api/recruitment/scenario/compare"),
    "hiring_budget": os.getenv("API_HIRING_BUDGET_PATH", "/api/recruitment/budget"),
    "proposal_evaluation": os.getenv("API_PROPOSAL_EVALUATION_PATH", "/api/workforce/proposal/evaluate"),
    "policy_validation": os.getenv("API_POLICY_VALIDATION_PATH", "/api/recruitment/policy/validate"),
    "budget_evaluation": os.getenv("API_BUDGET_EVALUATION_PATH", "/api/recruitment/budget/evaluate"),
    "decision_recommendation": os.getenv("API_DECISION_RECOMMENDATION_PATH", "/api/workforce/decision/recommendation"),
    "decision_evidence": os.getenv("API_DECISION_EVIDENCE_PATH", "/api/workforce/decision/evidence"),
    "report_data": os.getenv("API_REPORT_DATA_PATH", "/api/reports/workforce/data"),
    "report_summary": os.getenv("API_REPORT_SUMMARY_PATH", "/api/reports/workforce/summary"),
    "report_history": os.getenv("API_REPORT_HISTORY_PATH", "/api/reports/workforce/history"),
    "recipient_validation": os.getenv("API_RECIPIENT_VALIDATION_PATH", "/api/reports/recipients/validate"),
    "recruitment_policy": os.getenv("API_RECRUITMENT_POLICY_PATH", "/api/recruitment/policy"),
    "brand_template": os.getenv("API_BRAND_TEMPLATE_PATH", "/api/recruitment/brand-template"),
}

def _init_db() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS poster_requests (
                poster_id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                prompt TEXT NOT NULL,
                image_url TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                approved_by TEXT,
                approved_at TEXT
            )
        """)
        conn.commit()

def _api_get(endpoint_key: str, params: dict[str, Any]) -> dict[str, Any]:
    """Call a fixed, configured read-only Workforce API endpoint."""
    if not API_BASE_URL:
        raise RuntimeError("WORKFORCE_API_BASE_URL chưa được cấu hình trong file .env")
    path = ENDPOINTS[endpoint_key]
    query = urllib.parse.urlencode(
        {k: v for k, v in params.items() if v is not None and v != ""},
        doseq=True,
    )
    url = f"{API_BASE_URL}{path}"
    if query:
        url += ("&" if "?" in url else "?") + query

    headers = {"Accept": "application/json"}
    if API_TOKEN:
        headers["Authorization"] = f"Bearer {API_TOKEN}"
    req = urllib.request.Request(url, headers=headers, method="GET")

    try:
        with urllib.request.urlopen(req, timeout=API_TIMEOUT) as response:
            raw = response.read().decode("utf-8")
            data = json.loads(raw) if raw else {}
            return {"ok": True, "endpoint": path, "data": data}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")[:2000]
        log.exception("API HTTP error")
        return {"ok": False, "endpoint": path, "status_code": exc.code, "error": body}
    except Exception as exc:
        log.exception("API request failed")
        return {"ok": False, "endpoint": path, "error": str(exc)}

def _require(value: str, name: str) -> str:
    value = (value or "").strip()
    if not value:
        raise ValueError(f"{name} không được để trống")
    return value

def _poster_prompt(payload: dict[str, Any]) -> str:
    position = payload.get("position", "Công nhân sản xuất")
    quantity = payload.get("recruitment_quantity", "Chưa xác định")
    plant = payload.get("plant", "Nhà máy")
    location = payload.get("location", "Liên hệ HR để biết địa điểm")
    salary = payload.get("salary", {})
    currency = salary.get("currency", "VND")
    salary_lines = []
    for key, label in [
        ("base", "Lương cơ bản"), ("allowance", "Phụ cấp"),
        ("skill_allowance", "Phụ cấp kỹ năng"), ("bonus_max", "Thưởng tối đa")
    ]:
        if salary.get(key) is not None:
            salary_lines.append(f"{label}: {salary[key]:,} {currency}")
    benefits = payload.get("benefits", [])
    benefits_text = ", ".join(str(x) for x in benefits) if benefits else "Theo chính sách công ty"
    return (
        "Thiết kế poster tuyển dụng phong cách social hiện đại, chuyên nghiệp, dễ đọc. "
        "Ngôn ngữ: tiếng Việt. Tỷ lệ dọc 4:5, kích thước mục tiêu 1080x1350. "
        "Không tự thêm thông tin không có trong dữ liệu. Không tự bịa số điện thoại, địa chỉ, "
        "mức lương hoặc quyền lợi. Chừa vùng logo để chèn logo chính thức.\n"
        f"Nhà máy: {plant}\nVị trí: {position}\nSố lượng tuyển: {quantity} người\n"
        f"Địa điểm: {location}\n" + "\n".join(salary_lines) +
        f"\nQuyền lợi: {benefits_text}\n"
        "Ưu tiên bố cục rõ ràng: tiêu đề tuyển dụng, số lượng, vị trí, lương, quyền lợi, địa điểm. "
        "Kiểm tra chính tả tiếng Việt; không thêm nội dung chưa được cung cấp."
    )

# -------------------- FORECAST TOOLS --------------------

@MCP.tool()
def get_production_plan(plant: str = "", line: str = "", start_date: str = "", end_date: str = "") -> dict:
    """Lấy kế hoạch sản xuất theo nhà máy, line và khoảng ngày từ Production API."""
    return _api_get("production_plan", {"plant": plant, "line": line, "start_date": start_date, "end_date": end_date})

@MCP.tool()
def get_daily_manpower_standard(plant: str = "", line: str = "", model: str = "", work_date: str = "") -> dict:
    """Lấy tiêu chuẩn nhân lực theo ngày, line và model."""
    return _api_get("manpower_standard", {"plant": plant, "line": line, "model": model, "work_date": work_date})

@MCP.tool()
def get_available_workforce(plant: str = "", line: str = "", as_of_date: str = "") -> dict:
    """Lấy tổng nhân lực khả dụng; API nên trả số liệu tổng hợp, không trả PII không cần thiết."""
    return _api_get("available_workforce", {"plant": plant, "line": line, "as_of_date": as_of_date})

@MCP.tool()
def forecast_workforce_demand(plant: str, line: str, start_date: str, end_date: str) -> dict:
    """Dự báo nhu cầu nhân lực và workforce gap trong khoảng thời gian."""
    return _api_get("workforce_forecast", {"plant": plant, "line": line, "start_date": start_date, "end_date": end_date})

@MCP.tool()
def calculate_workforce_gap(required_workers: int, available_workers: int) -> dict:
    """Tính khoảng thiếu nhân lực đơn giản từ hai số liệu đã được Agent/API xác minh."""
    if required_workers < 0 or available_workers < 0:
        raise ValueError("Số lượng nhân lực không được âm")
    gap = max(required_workers - available_workers, 0)
    surplus = max(available_workers - required_workers, 0)
    return {"required_workers": required_workers, "available_workers": available_workers, "workforce_gap": gap, "surplus_workers": surplus}

# -------------------- RISK TOOLS --------------------

@MCP.tool()
def get_attendance_rate(plant: str = "", line: str = "", start_date: str = "", end_date: str = "") -> dict:
    """Lấy tỷ lệ đi làm theo nhà máy, line và thời gian."""
    return _api_get("attendance_rate", {"plant": plant, "line": line, "start_date": start_date, "end_date": end_date})

@MCP.tool()
def get_absenteeism_trend(plant: str = "", line: str = "", start_date: str = "", end_date: str = "") -> dict:
    """Lấy xu hướng vắng mặt theo thời gian."""
    return _api_get("absenteeism_trend", {"plant": plant, "line": line, "start_date": start_date, "end_date": end_date})

@MCP.tool()
def get_turnover_rate(plant: str = "", line: str = "", start_date: str = "", end_date: str = "") -> dict:
    """Lấy tỷ lệ nghỉ việc và xu hướng nghỉ việc."""
    return _api_get("turnover_rate", {"plant": plant, "line": line, "start_date": start_date, "end_date": end_date})

@MCP.tool()
def analyze_workforce_risk(plant: str, line: str, period: str) -> dict:
    """Gọi Risk API để đánh giá nguy cơ thiếu hụt nhân lực."""
    return _api_get("risk_analysis", {"plant": plant, "line": line, "period": period})

@MCP.tool()
def get_workforce_risk_alerts(plant: str = "", severity: str = "", from_date: str = "", to_date: str = "") -> dict:
    """Lấy danh sách cảnh báo rủi ro nhân lực."""
    return _api_get("risk_alerts", {"plant": plant, "severity": severity, "from_date": from_date, "to_date": to_date})

# -------------------- STRATEGY TOOLS --------------------

@MCP.tool()
def calculate_recruitment_quantity(plant: str, line: str, period: str) -> dict:
    """Tính số lượng cần tuyển từ nhu cầu, nhân lực hiện có và các giả định được API quản lý."""
    return _api_get("recruitment_quantity", {"plant": plant, "line": line, "period": period})

@MCP.tool()
def calculate_recruitment_cost(plant: str, position: str, quantity: int, currency: str = "VND") -> dict:
    """Ước tính chi phí tuyển dụng/lương theo số lượng và chính sách đã cấu hình trong API."""
    if quantity < 0:
        raise ValueError("quantity không được âm")
    return _api_get("recruitment_cost", {"plant": plant, "position": position, "quantity": quantity, "currency": currency})

@MCP.tool()
def simulate_hiring_scenario(plant: str, position: str, quantity: int, start_date: str = "") -> dict:
    """Mô phỏng một kịch bản tuyển dụng."""
    if quantity < 0:
        raise ValueError("quantity không được âm")
    return _api_get("hiring_scenario", {"plant": plant, "position": position, "quantity": quantity, "start_date": start_date})

@MCP.tool()
def compare_recruitment_scenarios(plant: str, scenarios_json: str) -> dict:
    """So sánh các kịch bản tuyển dụng; scenarios_json là JSON theo schema do Recruitment API quy định."""
    try:
        scenarios = json.loads(scenarios_json)
    except json.JSONDecodeError as exc:
        raise ValueError("scenarios_json không phải JSON hợp lệ") from exc
    return _api_get("scenario_comparison", {"plant": plant, "scenarios": json.dumps(scenarios, ensure_ascii=False)})

@MCP.tool()
def estimate_hiring_budget(plant: str, position: str, quantity: int, months: int = 1) -> dict:
    """Ước tính ngân sách tuyển dụng và chi phí nhân sự trong số tháng."""
    if quantity < 0 or months < 1:
        raise ValueError("quantity phải >= 0 và months phải >= 1")
    return _api_get("hiring_budget", {"plant": plant, "position": position, "quantity": quantity, "months": months})

# -------------------- DECISION TOOLS --------------------

@MCP.tool()
def evaluate_workforce_proposal(proposal_json: str) -> dict:
    """Đánh giá đề xuất nhân lực; không tự phê duyệt hoặc ghi dữ liệu HR."""
    try:
        payload = json.loads(proposal_json)
    except json.JSONDecodeError as exc:
        raise ValueError("proposal_json không phải JSON hợp lệ") from exc
    return _api_get("proposal_evaluation", {"proposal": json.dumps(payload, ensure_ascii=False)})

@MCP.tool()
def validate_recruitment_policy(plant: str, position: str, quantity: int) -> dict:
    """Kiểm tra đề xuất tuyển dụng theo chính sách hiện hành."""
    return _api_get("policy_validation", {"plant": plant, "position": position, "quantity": quantity})

@MCP.tool()
def evaluate_budget_limit(plant: str, requested_budget: float, currency: str = "VND") -> dict:
    """Kiểm tra ngân sách đề xuất so với hạn mức được API trả về."""
    if requested_budget < 0:
        raise ValueError("requested_budget không được âm")
    return _api_get("budget_evaluation", {"plant": plant, "requested_budget": requested_budget, "currency": currency})

@MCP.tool()
def generate_decision_recommendation(proposal_json: str) -> dict:
    """Tạo khuyến nghị quyết định dựa trên dữ liệu và chính sách; kết quả chỉ là đề xuất."""
    try:
        payload = json.loads(proposal_json)
    except json.JSONDecodeError as exc:
        raise ValueError("proposal_json không phải JSON hợp lệ") from exc
    return _api_get("decision_recommendation", {"proposal": json.dumps(payload, ensure_ascii=False)})

@MCP.tool()
def get_decision_evidence(decision_id: str) -> dict:
    """Lấy căn cứ dữ liệu cho một quyết định/đề xuất."""
    return _api_get("decision_evidence", {"decision_id": decision_id})

# -------------------- REPORT TOOLS --------------------

@MCP.tool()
def collect_workforce_report_data(plant: str, start_date: str, end_date: str, line: str = "") -> dict:
    """Thu thập dữ liệu tổng hợp phục vụ báo cáo workforce."""
    return _api_get("report_data", {"plant": plant, "line": line, "start_date": start_date, "end_date": end_date})

@MCP.tool()
def format_report_summary(report_data_json: str, language: str = "vi") -> dict:
    """Gửi dữ liệu báo cáo đã tổng hợp tới Report API để chuẩn hóa cấu trúc tóm tắt."""
    try:
        payload = json.loads(report_data_json)
    except json.JSONDecodeError as exc:
        raise ValueError("report_data_json không phải JSON hợp lệ") from exc
    return _api_get("report_summary", {"data": json.dumps(payload, ensure_ascii=False), "language": language})

@MCP.tool()
def get_report_history(plant: str, limit: int = 10) -> dict:
    """Tra cứu lịch sử báo cáo workforce."""
    return _api_get("report_history", {"plant": plant, "limit": max(1, min(limit, 100))})

@MCP.tool()
def validate_report_recipients(recipients_json: str) -> dict:
    """Kiểm tra danh sách email nhận báo cáo theo allowlist của hệ thống."""
    try:
        recipients = json.loads(recipients_json)
    except json.JSONDecodeError as exc:
        raise ValueError("recipients_json không phải JSON hợp lệ") from exc
    return _api_get("recipient_validation", {"recipients": json.dumps(recipients, ensure_ascii=False)})

# -------------------- POSTER TOOLS --------------------

@MCP.tool()
def get_recruitment_policy(plant: str, position: str = "") -> dict:
    """Lấy chính sách tuyển dụng đã được HR xác nhận."""
    return _api_get("recruitment_policy", {"plant": plant, "position": position})

@MCP.tool()
def get_brand_template(plant: str = "") -> dict:
    """Lấy thông tin nhận diện thương hiệu/template poster từ API."""
    return _api_get("brand_template", {"plant": plant})

@MCP.tool()
def validate_recruitment_data(data_json: str) -> dict:
    """Kiểm tra dữ liệu đầu vào trước khi tạo poster; không xác minh tính đúng của dữ liệu nguồn."""
    try:
        data = json.loads(data_json)
    except json.JSONDecodeError as exc:
        raise ValueError("data_json không phải JSON hợp lệ") from exc
    required = ["plant", "position", "recruitment_quantity", "location"]
    missing = [key for key in required if data.get(key) in (None, "")]
    quantity = data.get("recruitment_quantity")
    if quantity is not None and (not isinstance(quantity, int) or quantity < 0):
        return {"valid": False, "errors": ["recruitment_quantity phải là số nguyên >= 0"]}
    return {"valid": not missing, "errors": [f"Thiếu trường: {x}" for x in missing], "checked_fields": required}

@MCP.tool()
def prepare_poster_prompt(data_json: str) -> dict:
    """Tạo prompt tiếng Việt từ dữ liệu tuyển dụng đã được kiểm tra."""
    try:
        data = json.loads(data_json)
    except json.JSONDecodeError as exc:
        raise ValueError("data_json không phải JSON hợp lệ") from exc
    validation = validate_recruitment_data(data_json)
    if not validation["valid"]:
        return {"ok": False, "validation": validation}
    return {"ok": True, "prompt": _poster_prompt(data)}

@MCP.tool()
def create_poster_request(data_json: str) -> dict:
    """Tạo bản ghi yêu cầu poster trong SQLite cục bộ; không gọi Image Generator."""
    try:
        data = json.loads(data_json)
    except json.JSONDecodeError as exc:
        raise ValueError("data_json không phải JSON hợp lệ") from exc
    validation = validate_recruitment_data(data_json)
    if not validation["valid"]:
        return {"ok": False, "validation": validation}
    import uuid
    poster_id = "POSTER-" + uuid.uuid4().hex[:10].upper()
    prompt = _poster_prompt(data)
    now = datetime.now(timezone.utc).isoformat()
    _init_db()
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO poster_requests(poster_id,status,payload_json,prompt,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            (poster_id, "REQUESTED", json.dumps(data, ensure_ascii=False), prompt, now, now),
        )
        conn.commit()
    return {"ok": True, "poster_id": poster_id, "status": "REQUESTED", "prompt": prompt}

@MCP.tool()
def register_poster_result(poster_id: str, image_url: str) -> dict:
    """Lưu URL ảnh do Image Generator trả về; chấp nhận HTTPS URL בלבד."""
    image_url = _require(image_url, "image_url")
    parsed = urllib.parse.urlparse(image_url)
    if parsed.scheme != "https" or not parsed.netloc:
        raise ValueError("image_url phải là HTTPS URL hợp lệ")
    _init_db()
    now = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute(
            "UPDATE poster_requests SET image_url=?, status='AWAITING_APPROVAL', updated_at=? WHERE poster_id=?",
            (image_url, now, poster_id),
        )
        conn.commit()
        if cur.rowcount == 0:
            return {"ok": False, "error": "Không tìm thấy poster_id"}
    return {"ok": True, "poster_id": poster_id, "status": "AWAITING_APPROVAL", "image_url": image_url}

@MCP.tool()
def approve_poster(poster_id: str, approved_by: str, approval_confirmed: bool) -> dict:
    """Ghi nhận phê duyệt của người dùng; chỉ gọi khi có xác nhận phê duyệt rõ ràng."""
    if not approval_confirmed:
        return {"ok": False, "error": "Chưa có xác nhận phê duyệt rõ ràng"}
    approved_by = _require(approved_by, "approved_by")
    _init_db()
    now = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute(
            "UPDATE poster_requests SET status='APPROVED', approved_by=?, approved_at=?, updated_at=? "
            "WHERE poster_id=? AND status='AWAITING_APPROVAL'",
            (approved_by, now, now, poster_id),
        )
        conn.commit()
        if cur.rowcount == 0:
            return {"ok": False, "error": "Không tìm thấy yêu cầu hoặc poster chưa ở trạng thái AWAITING_APPROVAL"}
    return {"ok": True, "poster_id": poster_id, "status": "APPROVED"}

@MCP.tool()
def get_poster_status(poster_id: str) -> dict:
    """Tra cứu trạng thái yêu cầu poster."""
    _init_db()
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT * FROM poster_requests WHERE poster_id=?", (poster_id,)).fetchone()
    if not row:
        return {"ok": False, "error": "Không tìm thấy poster_id"}
    result = dict(row)
    result["payload"] = json.loads(result.pop("payload_json"))
    return {"ok": True, "poster": result}

if __name__ == "__main__":
    _init_db()
    # Streamable HTTP endpoint: http://HOST:8000/mcp
    MCP.run(
        transport="streamable-http",
        host=os.getenv("MCP_HOST", "0.0.0.0"),
        port=int(os.getenv("MCP_PORT", "8000")),
        stateless_http=True,
        json_response=True,
    )
