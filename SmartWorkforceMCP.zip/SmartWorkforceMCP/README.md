# Smart Workforce MCP

Python MCP Server for Columbus Smart Workforce Agents.

## Architecture

Columbus Agent -> MCP tools -> Read-only Workforce REST APIs -> SQL Server

MCP does not connect directly to SQL Server. Configure the API base URL and routes in `.env`.
The poster request lifecycle is stored in a local SQLite database; image generation and Outlook
email sending remain Columbus plugins and are invoked by the Agent, not by this MCP server.

## Requirements

- Python 3.11+
- Read-only Workforce API reachable from the MCP host
- Columbus can reach the MCP host over HTTPS (recommended for deployment)

## Windows setup

```powershell
cd D:\SmartWorkforce\SmartWorkforceMCP
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
notepad .env
python -m smartworkforce_mcp.server
```

Endpoint: `http://localhost:8000/mcp`

For Columbus on another machine, use the MCP host LAN IP and port, for example:
`http://10.69.240.42:8000/mcp` (replace with the actual reachable IP).
Production deployment should use HTTPS, authentication, firewall allowlisting and a reverse proxy/API gateway.
Do not expose this unauthenticated development endpoint directly to the Internet.

## Configure the API

Edit `.env`:
- `WORKFORCE_API_BASE_URL`: base URL of your existing API.
- `WORKFORCE_API_TOKEN`: bearer token if your API requires it.
- `API_*_PATH`: actual API route paths.

The API routes in `.env.example` are illustrative placeholders, not routes known to exist in your factory.
Adapt query parameter names and response schemas to your real API contract.

Every API-backed MCP tool uses GET only in this starter implementation. Keep the API identity read-only.
If an API needs POST for a calculation, expose a safe read-only calculation endpoint or adapt it after
reviewing the API contract; do not grant write access to employee/production tables.

## Tool groups

- Forecast: `get_production_plan`, `get_daily_manpower_standard`, `get_available_workforce`,
  `forecast_workforce_demand`, `calculate_workforce_gap`
- Risk: `get_attendance_rate`, `get_absenteeism_trend`, `get_turnover_rate`,
  `analyze_workforce_risk`, `get_workforce_risk_alerts`
- Strategy: `calculate_recruitment_quantity`, `calculate_recruitment_cost`,
  `simulate_hiring_scenario`, `compare_recruitment_scenarios`, `estimate_hiring_budget`
- Decision: `evaluate_workforce_proposal`, `validate_recruitment_policy`, `evaluate_budget_limit`,
  `generate_decision_recommendation`, `get_decision_evidence`
- Report: `collect_workforce_report_data`, `format_report_summary`, `get_report_history`,
  `validate_report_recipients`
- Poster: `get_recruitment_policy`, `get_brand_template`, `validate_recruitment_data`,
  `prepare_poster_prompt`, `create_poster_request`, `register_poster_result`,
  `approve_poster`, `get_poster_status`

## Test with MCP Inspector

```powershell
npx -y @modelcontextprotocol/inspector
```

Choose Streamable HTTP and connect to `http://localhost:8000/mcp`.
Try `calculate_workforce_gap` with `required_workers=150`, `available_workers=120`.
For API-backed tools, first configure a reachable API and its actual route paths.

## Columbus setup

Connect the MCP endpoint in the Advanced Toolkit / MCP section of the relevant Agent.
If Columbus allows per-tool selection, assign only the corresponding group to each Agent.
If it only allows server-level access, use separate MCP deployments/endpoints per permission group
or ask the Columbus administrator whether tool filtering is supported.

Recommended mapping:
- Forecast Agent -> Forecast tools
- Risk Agent -> Risk tools
- Strategy Agent -> Strategy tools
- Decision Agent -> Decision tools
- Report & Email Agent -> Report tools
- Recruitment Poster Agent -> Poster tools

The Image Generator and Send E-Mail are Columbus plugins. The Agent should call those plugins after
receiving the prompt or approved poster result. This MCP server does not pretend to invoke Columbus plugins.

## Important production notes

1. Replace all placeholder API routes with your real API contract.
2. Validate response fields and units (especially daily manpower standard, salary and bonus).
3. Avoid returning employee names, IDs, phone numbers or other PII unless essential.
4. Restrict API access to read-only database permissions.
5. Add authentication to the MCP endpoint and use HTTPS before connecting from another machine.
6. Poster approval in this starter is a workflow marker, not a legally binding e-signature.
7. `register_poster_result` accepts HTTPS URLs but does not download or inspect the image. Restrict allowed
   image-storage domains in production.
8. Do not send email or publish a poster until a human has explicitly approved it.
